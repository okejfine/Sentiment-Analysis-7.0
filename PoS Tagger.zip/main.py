## ALEX KING
import nltk, re
import collections

text = """This is the President of the United States. I want a government plan.
      However little known the feelings or views of such a man may be
      on his first entering a neighbourhood, this truth is so well
      fixed in the minds of the surrounding families, that he is
      considered as the rightful property of some one or other of their
      daughters. The government building."""
tokens = nltk.word_tokenize(text) # tokenize text
tag_list = nltk.pos_tag(tokens) # tag text as list of tuples
# tag_dict = dict(tag_list) # makes a dictionary of the tuples list

# using list comprehension to get names
postag = [lis[1] for lis in tag_list]
word = [lis[0] for lis in tag_list]

if len(tag_list) == len(tokens):
    print("yup")

pattern = re.compile(r'(NN|NNS)')
matches = pattern.finditer(str(tag_list))


# for match in matches:
#     print(match)

# printing result
# print("List with only 1th tuple element (i.e names) : " + str(postag))


